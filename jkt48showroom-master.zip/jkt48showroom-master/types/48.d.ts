// interface I48Member {
//   name: string;
//   kanji? : string;
//   isGraduate: boolean;
//   group: string;
//   description: string;
//   img: string;
//   stage48: string;
// }
