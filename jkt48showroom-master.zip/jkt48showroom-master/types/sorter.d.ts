/* eslint-disable unused-imports/no-unused-vars */
/* eslint-disable no-unused-vars */
enum GameState {
  IDLE,
  STARTED,
  FINISHED,
}
