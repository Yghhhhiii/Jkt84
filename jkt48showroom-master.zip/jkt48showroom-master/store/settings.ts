import ExpiredSerializer from '~~/library/serializer/expired'
import { skipHydrate } from 'pinia'

export const useSettings = defineStore('settings', () => {
  // const { status } = useAuth()
  const version = ref('')

  function setVersion(ver: string) {
    version.value = ver
  }

  const status = ref(null)
  const domain = ref('')
  const csrfToken = ref('')
  const authenticated = computed(() => {
    return status.value === 'authenticated'
  })

  const session = useSessionStorage<{ csrf_token: string, cookie: string } | null>('showroom_session', null, {
    serializer: new ExpiredSerializer<{ csrf_token: string, cookie: string } | null>(null, authenticated.value ? 1000 * 60 * 15 : 1000 * 60 * 5),
  })

  const subDomain = ref('')

  // const firstDate = computed(() => firstDateString.value ? new Date(firstDateString.value) : undefined)
  const firstDate = ref('2020-11-01T09:59:57.810Z')

  // async function fetchFirstDate() {
  //   try {
  //     firstDate.value = (await $apiFetch<{ date: string }>(`/api/first_data`)).date
  //   }
  //   catch (e) {
  //     console.log(e)
  //   }
  // }

  const group = computed(() => {
    switch (subDomain.value) {
      case '46' :{
        return 'hinatazaka46'
      }
      default : {
        return 'jkt48'
      }
    }
  })

  function setDomain(d: string) {
    domain.value = d
    subDomain.value = getSubdomain(d) ?? ''
  }

  const host = ref('')
  const path = ref('')
  function getSubdomain(domain: string): string {
    host.value = domain
    const parts = domain.split('.')
    return parts?.[0] || ''
  }

  const { getTitle } = useAppConfig()

  function getWebTitle() {
    return getTitle(group.value)
  }

  const currentURL = computed(() => `https://${host.value}${path.value}`)

  const route = useRoute()

  watch(() => route.fullPath, (p) => {
    path.value = p
  })
  return { domain, version, setVersion, setDomain, currentURL, getWebTitle, group, csrfToken, firstDate, session: skipHydrate(session) }
})

if (import.meta.hot) {
  import.meta.hot.accept(acceptHMRUpdate(useSettings, import.meta.hot))
}
