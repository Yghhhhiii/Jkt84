# JKT48 Showroom
A Website for JKT48 showroom history at https://dc.crstlnz.my.id/
