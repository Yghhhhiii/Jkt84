<template>
  <div class="bg-blue-500 text-white text-lg h-10 leading-10">
    <div class="flex-1 text-center">
      This is Announcement
    </div>
    <button type="button" aria-label="Close Announcement" class="absolute right-0 top-0 size-10 text-2xl flex items-center justify-center mr-1">
      <Icon name="heroicons:x-mark-16-solid" />
    </button>
  </div>
</template>
