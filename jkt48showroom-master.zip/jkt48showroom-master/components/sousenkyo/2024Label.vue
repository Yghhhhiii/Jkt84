<template>
  <NuxtLink to="/sousenkyo2024" class="bg-linear-to-r from-pink-400 via-purple-400 to-cyan-400 px-1 py-0.5 rounded-md flex gap-1 items-center border-yellow-300/50 border">
    <Icon name="mdi:crown-outline" class="text-yellow-300 text-base" /><div class="text-xs font-bold">
      Sousenkyo 2024
    </div>
  </NuxtLink>
</template>
