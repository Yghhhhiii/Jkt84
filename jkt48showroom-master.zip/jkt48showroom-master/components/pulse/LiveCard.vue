<template>
  <div
    class="pulse-color aspect-20/28 animate-pulse rounded-xl shadow-md md:aspect-20/26"
  />
</template>
